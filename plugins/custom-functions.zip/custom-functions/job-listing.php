<?php 
/*
	all functions for Job Listings will go here.
*/
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
 
class Job_Listing {
 
    public static function init() {
        add_action( 'init', array( __CLASS__, 'register_post_types' ), 5 );
        add_action( 'init', array( __CLASS__, 'add_job_region_taxonomy'));
        add_action( 'init', array( __CLASS__, 'add_job_type_taxonomy'));
    }

    public static function register_post_types() {

        // ___________ =OUR REVIEWS
        register_post_type( 'job_listings',
            array(
                'labels' => array(
                    'name'                  => 'Job Listings',
                    'singular_name'         => 'Job Listing',
                    'menu_name'             => 'Job Listings',
                    'add_new'               => 'Add New',
                    'add_new_item'          => 'Add New Listing',
                    'edit'                  => 'Edit',
                    'new_item'              => 'New Listing',
                    'view'                  => 'View Listing',
                    'search_item'           => 'Search Listing',
                    'not_found'             => 'No Teams found',
                    'not_found_in_trash'    => 'No Teams found in trash',
                    'parent'                => 'Parent Listing'
                ),

                register_taxonomy( 'job_listings_category', 'job_listings',
                    array(
                        'hierarchical'      => true,
                        'label'             => 'Job Categories',
                        'rewrite'           => array( 'slug' => 'job_listings_category' ),
                        'show_admin_column' => true,
                        'query_var'         => true
                    )
                ),

                'description'           => 'This is where you can add new Job Listing.',
                'public'                => true,
                'show_ui'               => true,
                'capability_type'       => 'page',
                'publicly_queryable'    => true,
                'hierarchical'          => false,
                'rewrite'               => array( 'slug' => 'job-listings' ),
                'query_var'             => true,
                'supports'              => array( 'title', 'thumbnail', 'editor' ),
                'has_archive'           => true,
                'show_in_nav_menus'     => true
            )
        );       
    }

	public static function add_job_region_taxonomy()  {
		$labels = array(
		    'name'                       => 'Job Region',
		    'singular_name'              => 'Job Region',
		    'menu_name'                  => 'Job Regions',
		    'all_items'                  => 'All Job Regions',
		    'parent_item'                => 'Parent Job Region',
		    'parent_item_colon'          => 'Parent Job Region:',
		    'new_item_name'              => 'New Job Region Name',
		    'add_new_item'               => 'Add New Job Region',
		    'edit_item'                  => 'Edit Job Region',
		    'update_item'                => 'Update Job Region',
		    'separate_items_with_commas' => 'Separate Job Region with commas',
		    'search_items'               => 'Search Job Region',
		    'add_or_remove_items'        => 'Add or remove Job Regions',
		    'choose_from_most_used'      => 'Choose from the most used Job Regions',
		);
		$args = array(
		    'labels'                     => $labels,
		    'hierarchical'               => true,
		    'public'                     => true,
		    'show_ui'                    => true,
		    'show_admin_column'          => true,
		    'show_in_nav_menus'          => true,
		    'show_tagcloud'              => true,
		);
		register_taxonomy( 'job-regions', 'job_listings', $args );
		register_taxonomy_for_object_type( 'job-regions', 'job_listings' );
	}

	public static function add_job_type_taxonomy()  {
		$labels = array(
		    'name'                       => 'Job Type',
		    'singular_name'              => 'Job Type',
		    'menu_name'                  => 'Job Types',
		    'all_items'                  => 'All Job Types',
		    'parent_item'                => 'Parent Job Type',
		    'parent_item_colon'          => 'Parent Job Type:',
		    'new_item_name'              => 'New Job Type Name',
		    'add_new_item'               => 'Add New Job Type',
		    'edit_item'                  => 'Edit Job Type',
		    'update_item'                => 'Update Job Type',
		    'separate_items_with_commas' => 'Separate Job Type with commas',
		    'search_items'               => 'Search Job Type',
		    'add_or_remove_items'        => 'Add or remove Job Types',
		    'choose_from_most_used'      => 'Choose from the most used Job Types',
		);
		$args = array(
		    'labels'                     => $labels,
		    'hierarchical'               => true,
		    'public'                     => true,
		    'show_ui'                    => true,
		    'show_admin_column'          => true,
		    'show_in_nav_menus'          => true,
		    'show_tagcloud'              => true,
	        'publicly_queryable' => true,
    	    'query_var' => true,
        	'rewrite' => true,
		);
		register_taxonomy( 'job-types', 'job_listings', $args );
		register_taxonomy_for_object_type( 'job-types', 'job_listings' );
	}


    public static function Industries(){
		return get_terms( array(
		    'taxonomy' => 'job_listings_category',
		    'hide_empty' => false,
		) );
		/*EXAMPLE OF RETURNED OBJECT
			array(4) {
			  [0]=>
			  object(WP_Term)#587 (10) {
			    ["term_id"]=>
			    int(5)
			    ["name"]=>
			    string(20) "Accounting / Finance"
			    ["slug"]=>
			    string(18) "accounting-finance"
			    ["term_group"]=>
			    int(0)
			    ["term_taxonomy_id"]=>
			    int(5)
			    ["taxonomy"]=>
			    string(21) "job_listings_category"
			    ["description"]=>
			    string(0) ""
			    ["parent"]=>
			    int(0)
			    ["count"]=>
			    int(0)
			    ["filter"]=>
			    string(3) "raw"
			  }
			  [1]=>
			  object(WP_Term)#588 (10) {
			    ["term_id"]=>
			    int(6)
			    ["name"]=>
			    string(22) "Admin / Human Resource"
			    ["slug"]=>
			    string(20) "admin-human-resource"
			    ["term_group"]=>
			    int(0)
			    ["term_taxonomy_id"]=>
			    int(6)
			    ["taxonomy"]=>
			    string(21) "job_listings_category"
			    ["description"]=>
			    string(0) ""
			    ["parent"]=>
			    int(0)
			    ["count"]=>
			    int(0)
			    ["filter"]=>
			    string(3) "raw"
			  }
			}  
		*/
	}

	public static function Regions(){
		return get_terms( array(
		    'taxonomy' => 'job-regions',
		    'hide_empty' => false,
		) );
	}
	
	public static function Types(){
		return get_terms( array(
		    'taxonomy' => 'job-types',
		    'hide_empty' => false,
		) );
	}

}
 
Job_Listing::init();

?>