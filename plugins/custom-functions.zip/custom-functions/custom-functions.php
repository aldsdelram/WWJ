<?php
/*
Plugin Name: Skubbs Custom Functions
Plugin URI:
Description: Adds some shortcodes and functions for custom functionality
Author: Skubbs
Version: 1.1
Author URI:
Network: true
*/

// ************************************
// =EXTERNAL LINKS
// ************************************

	include( plugin_dir_path( __FILE__ ) . '/custom-shortcodes.php'); 
	include( plugin_dir_path( __FILE__ ) . '/job-listing.php'); 

// ************************************
// =ACTIONS
// ************************************


//test code // for testing
	function test_code_here(){
	}
	add_action('init', 'test_code_here');
// ENQUEUE SCRIPTS
	function custom_plugin_scripts() {
		// wp_enqueue_style( 'slick-css', plugin_dir_url( __FILE__ ) . '/slick/slick.css');
		// wp_enqueue_style( 'slick-theme', plugin_dir_url( __FILE__ ) . '/slick/slick-theme.css');
		// wp_enqueue_script( 'slick-js', plugin_dir_url( __FILE__ ) . '/slick/slick.min.js', array(), '1.6.0', true );

		// wp_enqueue_style( 'featherlight-css', plugin_dir_url( __FILE__ ) . '/js/featherlight.min.css' );
		// wp_enqueue_script( 'featherlight-js', plugin_dir_url( __FILE__ ) . '/js/featherlight.min.js' );
		
		wp_enqueue_script( 'numeric', plugin_dir_url( __FILE__ ) . '/js/numeric.js', array() );
		wp_enqueue_script( 'sk-crp', plugin_dir_url( __FILE__ ) . '/js/sk_customize_registration_page.js', array() );
		wp_enqueue_script( 'sk-clp', plugin_dir_url( __FILE__ ) . '/js/sk_customize_login_page.js', array() );
		wp_enqueue_script( 'fix_input_number', plugin_dir_url( __FILE__ ) . '/js/fix_for_number_inputs.js', array() );
		wp_enqueue_script( 'cf-scripts', plugin_dir_url( __FILE__ ) . '/js/main.js', array() );
	}
	add_action( 'wp_enqueue_scripts', 'custom_plugin_scripts' );

// ENQUEUE STYLES
	function custom_plugin_styles() {
	 	wp_enqueue_style( 'jquery-ui-cdn-css', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css');
		wp_enqueue_style( 'cf-css', plugin_dir_url( __FILE__ ) . '/css/cf-css.css');
		wp_enqueue_style( 'sk-crp', plugin_dir_url( __FILE__ ) . '/css/sk_customize_registration_page.css');
		wp_enqueue_style( 'sk-clp', plugin_dir_url( __FILE__ ) . '/css/sk_customize_login_page.css');
	}
	add_action( 'wp_enqueue_scripts', 'custom_plugin_styles' );

//ENQUEUE LAST
	function bottom_scripts(){
		wp_enqueue_script('date', plugin_dir_url( __FILE__ ) . '/js/date.js', array());
		wp_enqueue_script('prev_and_next', plugin_dir_url( __FILE__ ) . '/js/functions_for_list.js', array());
	}
	add_action( 'wp_enqueue_scripts', 'bottom_scripts', PHP_INT_MAX);

//MAIN VARIABLES TO BE USED BY JAVASCRIPTS
	function main_variables(){
		echo "<script type=\"text/javascript\">".
	        "home_url = '".home_url()."';".
	      "</script>";
	}
	add_action ( 'wp_head', 'main_variables' );



// ************************************
// =FILTERS
// ************************************

	function add_content_on_registration(){
		echo '<span class="login_link_for_registration">Already have an Account? <a href="#">Log In</a></span>';
	}
	add_filter('upme_register_after_fields', 'add_content_on_registration');


	function change_dollar_to_sgd( $currency_symbol, $currency ) {
	     switch( $currency ) {
	          case 'SGD': $currency_symbol = 'SGD$'; break;
	     }
	     return $currency_symbol;
	}
	add_filter('woocommerce_currency_symbol', 'change_dollar_to_sgd', 10, 2);